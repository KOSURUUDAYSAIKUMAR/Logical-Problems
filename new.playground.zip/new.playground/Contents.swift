import UIKit

var greeting = "Hello, playground"


//func twoLongestPairArray(number: [Int], target: Int) -> [Int] {
//    var output = [Int: Int]()
//    for element in number {
//        let difference = target - element
//        if let value = output[difference] {
//           return [value, element]
//        }
//        output[element] = element
//    }
//    return []
//}
//
//print(twoLongestPairArray(number: [3,2,1], target: 5))



import Foundation


print(longestValidParentheses("(()"), "1--------") // Output: "()"
print(longestValidParentheses(")()())"), "2--------") // Output: "()()"
print(longestValidParentheses(""), "3--------") // Output: ""
print(longestValidParentheses("))(())())"), "4--------") // (()) --- (())()
print(longestValidParentheses("()((()())"), "5--------") // (()())
print(longestValidParentheses("()(){{}}[[]]"), "6--------") // {{}}[[]]
print(longestValidParentheses("()(){}{}[][]"), "7--------") // ()(){}{}[][]
print(longestValidParentheses("()(())"), "8--------") // (())()
print(longestValidParentheses("()(())((()))"), "9--------") // ((())) // ()(())((()))
print(longestValidParentheses("(){{}}[[[]]]"), "10--------") // [[[]]]
print(longestValidParentheses("(){{{}}}[[]]"), "11--------") // {{{}}}
print(longestValidParentheses("(){{{}}}[[[]]]"), "12--------") // {{{}}}[[[]]]
print(longestValidParentheses("(()()){}[]"), "13--------") // (()())
print(longestValidParentheses("]][[]][]]"), "14--------") // [[]] - [[]][]
print(longestValidParentheses("[][[[][]]"), "15--------") // [[][]]
print(longestValidParentheses("(){{{}}}[[[]]]((()))"), "16--------") // {{{}}}[[[]]]((()))
print(longestValidParentheses(" "), "17--------") // ""
print(longestValidParentheses("(((([}{]"), "18--------") // ""
print(longestValidParentheses("(((("), "19--------") // ""
print(longestValidParentheses("{{{"), "20--------") // ""
print(longestValidParentheses("[[["), "21--------") // ""
print(longestValidParentheses("()"), "22--------") // ()
print(longestValidParentheses("{}"), "23--------") // {}
print(longestValidParentheses("[]"), "24--------") // []
print(longestValidParentheses("((([[}]]))"), "25--------") // ""
print(longestValidParentheses("[[[((]]))"), "26--------") // ""
print(longestValidParentheses("()(){}"), "27--------") // () ()
print(longestValidParentheses("( ) ( ) ]"), "28--------") // ( ) ( )
print(longestValidParentheses("[ [ ( ) ( { ) ] ]"), "29--------") // ( )
print(longestValidParentheses("[[[][]]"), "30--------") // [[][]]
print(longestValidParentheses("[][[[][[]]]]"), "31--------") // [[[][[]]]] // [][[[][[]]]]
print(longestValidParentheses("((([[]])))"), "32--------")  // [[]]
print(longestValidParentheses("[[[{{()}}]]]"), "33--------") // ()
print(longestValidParentheses("[[[{{(}}]]]"), "34--------") // ""
print(longestValidParentheses(")()()("), "35--------") // "()()"
print(longestValidParentheses("[][[[]]"), "36--------") // [[]]
print(longestValidParentheses("(){}{}"), "37--------") // {}{}
print(longestValidParentheses("(){}()"), "38--------") // "(){}()" --- verify
print(longestValidParentheses("()()()"), "39--------") // ()()()
print(longestValidParentheses("()[]()[]()"), "40--------") // "()[]()[]()" --- verify
print(longestValidParentheses("()[][]"), "41--------") // "[][]"
print(longestValidParentheses("{[()()]{[][]"), "42--------") // [()()]


func longestValidParentheses(_ s: String) -> String {
    let output = finalOutputVerify(s) // Remove unused brackets in left side of input.
    let original = splitValidParentheses(output) // ["()", "{{}}"]
    let combinedResult = combineSimilarElements(original) // "()(){}", "(){}{}", "()[][]"
    if original.joined() == s {
        if combinedResult.joined() == s {
            return findLongestSubstring(combinedResult) // ["(": "(())", "[": "[[]]", "{": "{{}}", "(": "(({}))"]
        }
        return s // // // ()(){}{}[][]
    }
    let filtered = filteredTypeOfValidBrackets(original.joined()) // "()(())", "[[]][]"
    if filtered == original.joined() {
        return output
    }
    let longest = findLongestSubstring(original) // ["(": "(())", "[": "[[]]", "{": "{{}}", "(": "(({}))"]
    return finalOutputVerify(longest)
}

func finalOutputVerify(_ s: String) -> String {
    var stack = [-1]
    var longest = 0
    var start = 0
    let outputString = ""
    for (index, char) in s.enumerated() {
        if char == "(" || char == "{" || char == "[" {
            stack.append(index)
          //  stackCharacters.append(char)
        } else if char == ")" || char == "}" || char == "]" {
            stack.removeLast()
           // if stackCharacters.count != 0 { stackCharacters.removeLast() }
           // stackCharacters.removeLast()
            if stack.isEmpty {
              //  stackCharacters.append(char)
                stack.append(index)
            } else {
                let currentLength = index - stack.last!
                if currentLength > longest {
                    longest = currentLength
                    start = stack.last!
                }
            }
        }
    }
    if longest > 0 {
        let startIndex = s.index(s.startIndex, offsetBy: start + 1)
        let endIndex = s.index(startIndex, offsetBy: longest)
        let output = String(s[startIndex..<endIndex])
        return output
    }
    return outputString
}

func splitValidParentheses(_ s: String) -> [String] {
    var stack = [Int]()
    var output = [String]()
    for (index, char) in s.enumerated() {
        if char == "(" || char == "{" || char == "[" {
            stack.append(index)
        } else if char == ")" || char == "}" || char == "]" {
            if let openIndex = stack.popLast() {
                let substring = String(s[s.index(s.startIndex, offsetBy: openIndex)..<s.index(s.startIndex, offsetBy: index + 1)])
                output.append(substring)
            }
        }
    }
    return output
}


func combineSimilarElements(_ elements: [String]) -> [String] {
    var combinedElements: [String: Int] = [:]
    var order: [String] = []
    for element in elements {
        combinedElements[element, default: 0] += 1
        if !order.contains(element) {
            order.append(element)
        }
    }
    return order.compactMap { key in
        if let value = combinedElements[key] {
            return String(repeating: key, count: value)
        }
        return nil
    }
}


func isMatchingPair(_ opening: Character, _ closing: Character) -> Bool {
    return (opening == "(" && closing == ")") ||
    (opening == "{" && closing == "}") ||
    (opening == "[" && closing == "]")
}


func findLongestSubstring(_ substrings: [String]) -> String {
    guard let firstSubstring = substrings.first else {
        return "" // Empty array, return an empty string or handle as needed
    }
    let allSame = substrings.allSatisfy { $0 == firstSubstring }
    if allSame {
        return substrings.joined()
    }
    var maxLengths: [Character: String] = [:]
    for substring in substrings {
        var stack: [Character] = []
        var currentSubstring = ""
        for char in substring {
            if char == "(" || char == "{" || char == "[" {
                stack.append(char)
                currentSubstring.append(char)
            } else if char == ")" || char == "}" || char == "]" {
                if let lastOpening = stack.last, isMatchingPair(lastOpening, char) {
                    stack.removeLast()
                    currentSubstring.append(char)
                } else { // If the brackets are not balanced, reset the substring
                    currentSubstring = ""
                }
            } else {
                currentSubstring.append(char)
            }
        }
        if let existing = maxLengths[substring.first ?? "_"] {
            if currentSubstring.count > existing.count {
                maxLengths[substring.first ?? "_"] = currentSubstring
            }
        } else {
            maxLengths[substring.first ?? "_"] = currentSubstring
        }
    }
    var results: [String] = []
    
    var parenthesisCount = 0
    var curlyCount = 0
    var squareCount = 0
    var parenthesisValue = ""
    var curlyValue = ""
    var squareValue = ""
    for (key,value) in maxLengths {
        if key == "(" {
            parenthesisCount = value.count
            parenthesisValue = value
        }
        if key == "{" {
            curlyCount = value.count
            curlyValue = value
        }
        if key == "[" {
            squareCount = value.count
            squareValue = value
        }
    }

    if parenthesisCount == curlyCount && curlyCount  == squareCount {
        return maxLengths.values.joined()
    }
    //        return maxLengths.values.map({$0}).joined()
    else if parenthesisCount > curlyCount && parenthesisCount > squareCount {
        return parenthesisValue
        // Parenthesis count is the highest
    } else if curlyCount > parenthesisCount && curlyCount > squareCount {
        // Curly bracket count is the highest
        return curlyValue
    } else if squareCount > parenthesisCount && squareCount > curlyCount {
        // Square bracket count is the highest
        return squareValue
    } else {
        // Check which counts are the highest
        let maxCount = max(parenthesisCount, curlyCount, squareCount)
        
        if parenthesisCount == maxCount {
            results.append(maxLengths["("]!)
        }
        if curlyCount == maxCount {
            results.append(maxLengths["{"]!)
        }
        if squareCount == maxCount {
            results.append(maxLengths["["]!)
        }
        return results.joined()
    }
}

func filteredTypeOfValidBrackets(_ bracketDictionary: String) -> String {
    let validParentheses = bracketDictionary.contains("{") || bracketDictionary.contains("}") || bracketDictionary.contains("[") || bracketDictionary.contains("]")
    let validCurly = bracketDictionary.contains("(") || bracketDictionary.contains(")") || bracketDictionary.contains("[") || bracketDictionary.contains("]")
    let validSquare = bracketDictionary.contains("(") || bracketDictionary.contains(")") || bracketDictionary.contains("{") || bracketDictionary.contains("}")
    
    if !validParentheses {
        if bracketDictionary != " " {
            return bracketDictionary
        }
    }
    if !validCurly {
        if bracketDictionary != " " {
            return bracketDictionary
        }
    }
    if !validSquare {
        if bracketDictionary != " " {
            return bracketDictionary
        }
    }
    return ""
}
